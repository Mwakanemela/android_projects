package com.example.kotlinsendnotification

data class NotificationData (
    val title: String,
    val message:String

    )