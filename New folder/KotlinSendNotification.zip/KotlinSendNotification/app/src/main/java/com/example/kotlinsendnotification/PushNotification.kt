package com.example.kotlinsendnotification

data class PushNotification(
    val data:NotificationData,
    val to:String
)
