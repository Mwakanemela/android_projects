package com.example.kotlinsendnotification

class Constants {

    companion object {
        const val BASE_URL = "https://fcm.googleapis.com"
        const val SERVER_KEY = "AAAA_mlXm9s:APA91bEcNMvgA4_jUW4Bg1nK_oCXPaXpbTahJUm6NNolS_V-wzclW4hIJrRZm3q6IMIdENezsFkYw4CO0lMQNbm7N_R2GHVmoRJkgmm31vREH0vGtmmTpb97zp_0mWim8_pNWPIGwV6u"
        const val CONTENT_TYPE = "application/json"
    }
}