package com.example.appchat.calling.utils;

public interface ErrorCallBack {
    void onError();
}