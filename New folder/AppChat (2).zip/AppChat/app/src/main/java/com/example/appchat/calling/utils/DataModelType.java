package com.example.appchat.calling.utils;

public enum DataModelType {
    Offer, Answer, IceCandidate, StartCall
}