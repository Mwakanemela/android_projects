package com.example.appchat.msg_notification

data class PushNotification(
    val data:NotificationData,
    val to:String
)