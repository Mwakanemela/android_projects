package com.example.appchat.calling.utils;

public interface NewEventCallBack {
    void onNewEventReceived(DataModel model);
}