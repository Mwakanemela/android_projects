package com.example.appchat.calling.utils;

public interface SuccessCallBack {
    void onSuccess();
}