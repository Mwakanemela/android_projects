package com.example.appchat.msg_notification

data class NotificationData (
    val title: String,
    val message:String

)